// App Router

function AppRouter() {
  return (
    <div className="App">
      <h1>Weather App</h1>
    </div>
  );
}

export default AppRouter;
